
DEPENDENCY:

Download WINAVR to use the updater
https://sourceforge.net/projects/winavr/
____

Select COM Port using drop down menu.

Press Upload, and ensure there are no errors.

If there is an error such as .dll download WINAVR https://sourceforge.net/projects/winavr/

____

If you can't find your COM Port replug your B0XX then click on refresh.

____

LICENSE:
By using this program you agree to only use program and files contained, including but not limited the B0XX Hex files (20XX.hex), on official 20XX products such as the B0XX.  
